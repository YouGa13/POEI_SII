#include "Account.h"

bool create_account(int id, double balance) {
    if (numAccounts >= MAX_ACCOUNT) {
        return false;
    }
    Account account = { id, balance };
    listAccount[numAccounts] = account;
    numAccounts++;
    return true;
}

Account* get_account(int id) {
    for (int i = 0; i < numAccounts; i++) {
        if (listAccount[i].id == id) {
            return &listAccount[i];
        }
    }
    return NULL;
}

void withdraw(Account* account, double amount) {
    account->balance -= amount;
}

void deposit(Account* account, double amount) {
    account->balance += amount;
}
