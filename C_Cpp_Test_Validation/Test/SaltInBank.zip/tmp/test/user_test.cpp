#include "gtest/gtest.h"
extern "C" {
    #include "../User.h"
}

TEST(UserTest, DummyTest) {
    EXPECT_TRUE(true);
    EXPECT_FALSE(false);
    int test = 1;
    EXPECT_EQ(test, 1);
}
