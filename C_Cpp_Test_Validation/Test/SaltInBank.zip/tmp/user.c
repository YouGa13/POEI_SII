#include "User.h"
#include <string.h>

bool create_user(int id, char* name) {
    User user = { id, "" };
    strncpy(user.name, name, 50);
    if (numUsers < MAX_USER) {
        listUser[numUsers] = user;
        numUsers++;
        return true;
    }
    return false;
}

User* get_user(char* name) {
    for (int i = 0; i < numUsers; i++) {
        if (strcmp(listUser[i].name, name) == 0) {
            return &listUser[i];
        }
    }
    return NULL;
}