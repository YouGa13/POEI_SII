#ifndef USER_H
#define USER_H

#define MAX_USER 100

#include <stdbool.h>

typedef struct {
    int id;
    char name[50];
} User;

extern User listUser[MAX_USER];
extern int numUsers;

bool create_user(int id, char* name);

User* get_user(char* name);

#endif /* USER_H */
