#include <stdlib.h>

#include "gtest/gtest.h"

extern "C" {
    #include "../STMF100RegisterConfiguration.h"
}

TEST(STMF100Register, dummy) {
    EXPECT_EQ(get_APB2EN_register(GPIOA), 2);
    ASSERT_TRUE(true);
}